package is.hi.basketmob.dto;


public record TeamDto(String name) {}

package is.hi.basketmob.dto;

public record ErrorDto(String code, String message, String details) {}
